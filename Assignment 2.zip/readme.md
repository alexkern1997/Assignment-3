# Readme Assignment 2 Experimentation for Psychology, Linguistics and AI
### 09-03-2020
This readme file is about the data collected for the second assignment for MEPL at Utrecht University by Alex Kern(5711088) and Benedetta Ghedi(7005571).

# Data Format
The csv file is made up of 60 columns, each column representing a different word pair.
There are 21 rows, each row representing a different participant.
Each cell corresponds to the score the participant gave for that particular word pair.
